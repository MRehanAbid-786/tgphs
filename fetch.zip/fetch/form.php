<?php
include 'Connection.php'; // Include the database connection

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Insert the data into the database
    $query = "INSERT INTO crud (firstname, lastname, email, password) VALUES ('$firstname', '$lastname', '$email', '$password')";
    
    if (mysqli_query($conn, $query)) {
        echo "New record created successfully.";
        // Redirect to the display page after successful insertion (optional)
        header("Location: prac.php"); // Change to your display page
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert User</title>
</head>
<body>
    <h2>Insert User</h2>
    <form method="post" action="">
        <label for="firstname">First Name:</label>
        <input type="text" name="firstname" required><br><br>

        <label for="lastname">Last Name:</label>
        <input type="text" name="lastname" required><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br><br>

        <input type="submit" value="Insert User">
    </form>
</body>
</html>
