<?php
include 'Connection.php'; // Include the database connection

// Check if the form is submitted for updating the record
if (isset($_POST['update'])) {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Check if a new image is uploaded
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image);

        // Move uploaded image to the target directory
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

        // Update the user details including the image
        $query = "UPDATE crudImage SET firstname='$firstname', lastname='$lastname', email='$email', password='$password', image='$image' WHERE id=$id";
    } else {
        // Update the user details without changing the image
        $query = "UPDATE crudImage SET firstname='$firstname', lastname='$lastname', email='$email', password='$password' WHERE id=$id";
    }

    if (mysqli_query($conn, $query)) {
        echo "Record updated successfully.";
        header("Location: fetch.php");
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

// Check if the record to be edited is passed via GET method
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Fetch the record to be edited
    $query = "SELECT * FROM crudImage WHERE id=$id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Record not found.";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
</head>
<body>
    <h2>Edit User</h2>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <label for="firstname">First Name:</label>
        <input type="text" name="firstname" value="<?php echo $row['firstname']; ?>" required><br><br>

        <label for="lastname">Last Name:</label>
        <input type="text" name="lastname" value="<?php echo $row['lastname']; ?>" required><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo $row['email']; ?>" required><br><br>

        <label for="password">Password:</label>
        <input type="password" name="password" value="<?php echo $row['password']; ?>" required><br><br>

        <label for="image">Upload Image (Leave blank if not changing):</label>
        <input type="file" name="image"><br><br>

        <img src="uploads/<?php echo $row['image']; ?>" alt="User Image" width="100" height="100"><br><br>

        <input type="submit" name="update" value="Update">
    </form>
</body>
</html>
