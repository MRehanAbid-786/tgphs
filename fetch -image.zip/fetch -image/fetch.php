<?php
// Include the database connection
include 'Connection.php';

// Fetch data from the database
$query = "SELECT id, firstname, lastname, email, password, image FROM crudimage";
$result = mysqli_query($conn, $query);

// Check if any rows are returned
if (mysqli_num_rows($result) > 0) {
    // Output data of each row in a table
    echo "<table border='1'>
    <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Image</th>
        <th>Action</th>
    </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
            <td>" . ($row["firstname"]) . "</td>
            <td>" . ($row["lastname"]) . "</td>
            <td>" . ($row["email"]) . "</td>
            <td>" . ($row["password"]) . "</td>
            <td><img src='uploads/" . $row["image"] . "' alt='User Image' width='100' height='100'></td>
            <td>
                <a href='edit.php?id=" . $row["id"] . "'>Edit</a> | 
                <a href='delete.php?id=" . $row["id"] . "' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</a>
            </td>
        </tr>";
    }

    echo "</table>";
} else {
    echo "No records found.";
}

// Close the database connection
mysqli_close($conn);
?>
