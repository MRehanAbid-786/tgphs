<?php
include 'Connection.php'; // Include the database connection

// Check if an ID is passed via GET method
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Fetch the image file name to delete from the server
    $query = "SELECT image FROM crudImage WHERE id=$id";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $image = $row['image'];

    // Delete the record from the database
    $query = "DELETE FROM crudImage WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        // Also delete the image from the server
        if (file_exists("uploads/$image")) {
            unlink("uploads/$image");
        }

        echo "Record deleted successfully.";
        header("Location: fetch.php");
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    echo "No ID specified.";
}
