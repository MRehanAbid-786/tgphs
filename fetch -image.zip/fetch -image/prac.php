<?php 

include 'Connection.php';


$query ="Select  id ,firstname,lastname,email,password  From crud "  ;

$result = mysqli_query($conn,$query);



if (mysqli_num_rows($result) > 0) {
echo "<table>
			<tr>
			 <th>firstname</th>
			 <th>lastname</th>
			 <th>email</th>
			 <th>password</th>



			</tr>";

while ($row =mysqli_fetch_assoc($result)) {
	   
	echo "<tr>";
	   echo	"<td>".htmlspecialchars($row["firstname"])  ."</td>";
 echo "<td>" . htmlspecialchars($row["lastname"])  ."</td>";
 echo "<td>" .htmlspecialchars($row["email"])  ."</td>";
 echo  "<td>" .htmlspecialchars($row["password"])  . "</td>";


	 echo  "</tr>";
}


echo "</table>";

	
}else {
	echo "sorry";
}











 ?>