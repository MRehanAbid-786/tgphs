<?php
include 'Connection.php'; // Include the database connection

// Check if the form is submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data from the POST request
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Retrieve the uploaded image's name
    $image = $_FILES['image']['name'];
    // Define the directory where the image will be uploaded
    $target_file = "uploads/" . $image;

    // Move the uploaded image from its temporary location to the target directory
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Insert the form data and image path into the database
        $query = "INSERT INTO crudimage (firstname, lastname, email, password, image) 
                  VALUES ('$firstname', '$lastname', '$email', '$password', '$image')";
        
        // Execute the query and check if the insertion was successful
        if (mysqli_query($conn, $query)) {
            // If successful, redirect the user to the fetch.php page
            header("Location: fetch.php");
            exit();
        } else {
            // If there is an error with the query, display the error message
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        // If the file could not be uploaded, display an error message
        echo "Error uploading file.";
    }
}

// Close the database connection when done
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert User</title>
</head>
<body>
    <h2>Insert User</h2>
    <!-- Form to collect user data and image upload -->
    <form method="post" enctype="multipart/form-data">
        <!-- Input for first name -->
        <label>First Name:</label>
        <input type="text" name="firstname" required><br><br>

        <!-- Input for last name -->
        <label>Last Name:</label>
        <input type="text" name="lastname" required><br><br>

        <!-- Input for email -->
        <label>Email:</label>
        <input type="email" name="email" required><br><br>

        <!-- Input for password -->
        <label>Password:</label>
        <input type="password" name="password" required><br><br>

        <!-- Input for uploading an image -->
        <label>Upload Image:</label>
           <input type="file" name="image" required><br><br>

        <!-- Submit button to insert user -->
        <input type="submit" value="Insert User">
    </form>
</body>
</html>
